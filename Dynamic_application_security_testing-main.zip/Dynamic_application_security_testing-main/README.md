# Screenshot of Dynamic application security testing.
# 1.	Login page where SQL injection to be performed.
# 2.	Web page after SQL injection attack.
# 3.	Login page where cross site scripting to be performed.
# 4.	Web page after cross site scripting attack.
# 5.	Web page after security misconfiguration.
# 6.	Nessus dashboard screenshot after sensitive data disclosure.
# 7.	Sensitive data disclosed screenshot.
# 8.	Screenshot of broken authentication.
# 9.	Screenshot of broken access control.
# 10.	Screenshot of application uses components with known vulnerabilities.
# 11.	Screenshot of OWASP ZAP.
